---
name: Profile request
about: Request or contribute a machine/controller profile
title: ""
labels: profile
assignees: ""
---

## Machine / controller

- Manufacturer:
- Model:
- Controller:
- Protocol: Modbus RTU / Modbus TCP / other

## Register map source

Describe the source of the register list and confirm it is OK to share.

Do not upload proprietary manuals or customer documents unless you have permission.

## Known connection settings

- Baud:
- Serial format:
- Slave ID:
- Offset:

## Known display checks

List at least three values you can compare against the controller display.

| Point | Register | Display value | Raw value |
| --- | ---: | ---: | ---: |
| | | | |
