---
name: Bug report
about: Report a reading, profile, connection, or UI problem
title: ""
labels: bug
assignees: ""
---

## What happened?

Describe the problem clearly.

## Controller / machine

- Manufacturer:
- Model:
- Controller:
- Profile:

## Connection

- COM port:
- Baud:
- Serial format:
- Slave ID:
- Offset:
- Function code:

## Register / value

- Register:
- Expected value:
- Shown value:
- Controller display value, if known:

## Evidence

Attach an anonymised screenshot, CSV snapshot, or log if useful.

Do not upload customer names, site names, passwords, serial numbers, or private manuals.
